#include "cachelab.h"
#include "getopt.h"
#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"

// s = 5, E = 1, b = 5
// 2^s sets, 2^b bytes per block, E lines per set

int main()
{

    printSummary(0, 0, 0);
    return 0;
}
